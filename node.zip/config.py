import os
import folder_paths

CACHE_DIR = os.path.join(folder_paths.output_directory, "caching_to_not_waste")